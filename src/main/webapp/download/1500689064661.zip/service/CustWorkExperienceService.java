package com.longshare.cmsp.customer.management.service;

        import com.longshare.cmsp.customer.management.model.CustWorkExperienceVO;
        import com.longshare.cmsp.customer.management.orm.entity.CustWorkExperienceEntity;
        import com.longshare.cmsp.customer.management.orm.mapper.CustWorkExperienceMapper;
        import com.longshare.cmsp.customer.management.orm.param.CustWorkExperienceQueryBean;
        import com.longshare.cmsp.orm.support.model.Page;
        import com.longshare.cmsp.support.common.component.util.BeanHelper;
        import com.longshare.cmsp.support.micro.service.api.result.GenericPageVO;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.stereotype.Service;

        import java.util.ArrayList;
        import java.util.List;
        import java.util.UUID;

/**
 * Created by WongCU.
 */
@Service
public class CustWorkExperienceService {

        Logger logger = LoggerFactory.getLogger(CustWorkExperienceService.class);

@Autowired
    CustWorkExperienceMapper custWorkExperienceMapper;

/**
 * 分页查询工作经历
 * @param page
 * @param sort
 * @return
 */
public GenericPageVO<CustWorkExperienceVO> find(Page page, String sort, CustWorkExperienceQueryVO queryParam) {

        CustWorkExperienceQueryBean queryBean = BeanHelper.convertTo(queryParam,CustWorkExperienceQueryBean.class);
        queryBean.setOrderByStr(sort);
        Page<CustWorkExperienceEntity> entityPage = custWorkExperienceMapper.queryByPage(page, queryBean);
        List<CustWorkExperienceVO> custWorkExperienceVOS = new ArrayList<>();
        for (CustWorkExperienceEntity custWorkExperienceEntity : entityPage.getResults()) {
        CustWorkExperienceVO custWorkExperienceVO = BeanHelper.convertTo(custWorkExperienceEntity, CustWorkExperienceVO.class);
        custWorkExperienceVOS.add(custWorkExperienceVO);
        }
        return new GenericPageVO(entityPage.getTotalCount(), entityPage.getTotalPages(), custWorkExperienceVOS);
        }

/**
 * 根据ID查询工作经历
 * @param id
 * @return
 */
public CustWorkExperienceVO queryById(String id){
        CustWorkExperienceEntity entity = custWorkExperienceMapper.queryById(id);
        return BeanHelper.convertTo(entity,CustWorkExperienceVO.class);
        }

/**
 * 新增工作经历
 * @param custWorkExperienceVO
 */
public String insert(CustWorkExperienceVO custWorkExperienceVO){
        CustWorkExperienceEntity entity = BeanHelper.convertTo(custWorkExperienceVO,CustWorkExperienceEntity.class);
        entity.setworkExperienceId(UUID.randomUUID().toString());
        custWorkExperienceMapper.insert(entity);
        return entity.getworkExperienceId();
        }

/**
 * 更新工作经历
 * @param custWorkExperienceVO
 * @return
 */
public Boolean update(CustWorkExperienceVO custWorkExperienceVO){
        CustWorkExperienceEntity entity = BeanHelper.convertTo(custWorkExperienceVO,CustWorkExperienceEntity.class);
        return custWorkExperienceMapper.update(entity) == 1 ;
        }
        
/**
 * 删除工作经历
 * @param id
 * @return
 */
public Boolean delete(String id){
        return custWorkExperienceMapper.delete(id)==1;
        }

}
