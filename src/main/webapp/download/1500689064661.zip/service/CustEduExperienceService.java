package com.longshare.cmsp.customer.management.service;

        import com.longshare.cmsp.customer.management.model.CustEduExperienceVO;
        import com.longshare.cmsp.customer.management.orm.entity.CustEduExperienceEntity;
        import com.longshare.cmsp.customer.management.orm.mapper.CustEduExperienceMapper;
        import com.longshare.cmsp.customer.management.orm.param.CustEduExperienceQueryBean;
        import com.longshare.cmsp.orm.support.model.Page;
        import com.longshare.cmsp.support.common.component.util.BeanHelper;
        import com.longshare.cmsp.support.micro.service.api.result.GenericPageVO;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.stereotype.Service;

        import java.util.ArrayList;
        import java.util.List;
        import java.util.UUID;

/**
 * Created by WongCU.
 */
@Service
public class CustEduExperienceService {

        Logger logger = LoggerFactory.getLogger(CustEduExperienceService.class);

@Autowired
    CustEduExperienceMapper custEduExperienceMapper;

/**
 * 分页查询教育经历
 * @param page
 * @param sort
 * @return
 */
public GenericPageVO<CustEduExperienceVO> find(Page page, String sort, CustEduExperienceQueryVO queryParam) {

        CustEduExperienceQueryBean queryBean = BeanHelper.convertTo(queryParam,CustEduExperienceQueryBean.class);
        queryBean.setOrderByStr(sort);
        Page<CustEduExperienceEntity> entityPage = custEduExperienceMapper.queryByPage(page, queryBean);
        List<CustEduExperienceVO> custEduExperienceVOS = new ArrayList<>();
        for (CustEduExperienceEntity custEduExperienceEntity : entityPage.getResults()) {
        CustEduExperienceVO custEduExperienceVO = BeanHelper.convertTo(custEduExperienceEntity, CustEduExperienceVO.class);
        custEduExperienceVOS.add(custEduExperienceVO);
        }
        return new GenericPageVO(entityPage.getTotalCount(), entityPage.getTotalPages(), custEduExperienceVOS);
        }

/**
 * 根据ID查询教育经历
 * @param id
 * @return
 */
public CustEduExperienceVO queryById(String id){
        CustEduExperienceEntity entity = custEduExperienceMapper.queryById(id);
        return BeanHelper.convertTo(entity,CustEduExperienceVO.class);
        }

/**
 * 新增教育经历
 * @param custEduExperienceVO
 */
public String insert(CustEduExperienceVO custEduExperienceVO){
        CustEduExperienceEntity entity = BeanHelper.convertTo(custEduExperienceVO,CustEduExperienceEntity.class);
        entity.seteduExperienceId(UUID.randomUUID().toString());
        custEduExperienceMapper.insert(entity);
        return entity.geteduExperienceId();
        }

/**
 * 更新教育经历
 * @param custEduExperienceVO
 * @return
 */
public Boolean update(CustEduExperienceVO custEduExperienceVO){
        CustEduExperienceEntity entity = BeanHelper.convertTo(custEduExperienceVO,CustEduExperienceEntity.class);
        return custEduExperienceMapper.update(entity) == 1 ;
        }
        
/**
 * 删除教育经历
 * @param id
 * @return
 */
public Boolean delete(String id){
        return custEduExperienceMapper.delete(id)==1;
        }

}
