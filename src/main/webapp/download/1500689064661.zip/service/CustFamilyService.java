package com.longshare.cmsp.customer.management.service;

        import com.longshare.cmsp.customer.management.model.CustFamilyVO;
        import com.longshare.cmsp.customer.management.orm.entity.CustFamilyEntity;
        import com.longshare.cmsp.customer.management.orm.mapper.CustFamilyMapper;
        import com.longshare.cmsp.customer.management.orm.param.CustFamilyQueryBean;
        import com.longshare.cmsp.orm.support.model.Page;
        import com.longshare.cmsp.support.common.component.util.BeanHelper;
        import com.longshare.cmsp.support.micro.service.api.result.GenericPageVO;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.stereotype.Service;

        import java.util.ArrayList;
        import java.util.List;
        import java.util.UUID;

/**
 * Created by WongCU.
 */
@Service
public class CustFamilyService {

        Logger logger = LoggerFactory.getLogger(CustFamilyService.class);

@Autowired
    CustFamilyMapper custFamilyMapper;

/**
 * 分页查询家庭成员
 * @param page
 * @param sort
 * @return
 */
public GenericPageVO<CustFamilyVO> find(Page page, String sort, CustFamilyQueryVO queryParam) {

        CustFamilyQueryBean queryBean = BeanHelper.convertTo(queryParam,CustFamilyQueryBean.class);
        queryBean.setOrderByStr(sort);
        Page<CustFamilyEntity> entityPage = custFamilyMapper.queryByPage(page, queryBean);
        List<CustFamilyVO> custFamilyVOS = new ArrayList<>();
        for (CustFamilyEntity custFamilyEntity : entityPage.getResults()) {
        CustFamilyVO custFamilyVO = BeanHelper.convertTo(custFamilyEntity, CustFamilyVO.class);
        custFamilyVOS.add(custFamilyVO);
        }
        return new GenericPageVO(entityPage.getTotalCount(), entityPage.getTotalPages(), custFamilyVOS);
        }

/**
 * 根据ID查询家庭成员
 * @param id
 * @return
 */
public CustFamilyVO queryById(String id){
        CustFamilyEntity entity = custFamilyMapper.queryById(id);
        return BeanHelper.convertTo(entity,CustFamilyVO.class);
        }

/**
 * 新增家庭成员
 * @param custFamilyVO
 */
public String insert(CustFamilyVO custFamilyVO){
        CustFamilyEntity entity = BeanHelper.convertTo(custFamilyVO,CustFamilyEntity.class);
        entity.setfamilyId(UUID.randomUUID().toString());
        custFamilyMapper.insert(entity);
        return entity.getfamilyId();
        }

/**
 * 更新家庭成员
 * @param custFamilyVO
 * @return
 */
public Boolean update(CustFamilyVO custFamilyVO){
        CustFamilyEntity entity = BeanHelper.convertTo(custFamilyVO,CustFamilyEntity.class);
        return custFamilyMapper.update(entity) == 1 ;
        }
        
/**
 * 删除家庭成员
 * @param id
 * @return
 */
public Boolean delete(String id){
        return custFamilyMapper.delete(id)==1;
        }

}
