package com.longshare.cmsp.customer.management.service;

        import com.longshare.cmsp.customer.management.model.CustKeyDateVO;
        import com.longshare.cmsp.customer.management.orm.entity.CustKeyDateEntity;
        import com.longshare.cmsp.customer.management.orm.mapper.CustKeyDateMapper;
        import com.longshare.cmsp.customer.management.orm.param.CustKeyDateQueryBean;
        import com.longshare.cmsp.orm.support.model.Page;
        import com.longshare.cmsp.support.common.component.util.BeanHelper;
        import com.longshare.cmsp.support.micro.service.api.result.GenericPageVO;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.stereotype.Service;

        import java.util.ArrayList;
        import java.util.List;
        import java.util.UUID;

/**
 * Created by WongCU.
 */
@Service
public class CustKeyDateService {

        Logger logger = LoggerFactory.getLogger(CustKeyDateService.class);

@Autowired
    CustKeyDateMapper custKeyDateMapper;

/**
 * 分页查询客户重要日期
 * @param page
 * @param sort
 * @return
 */
public GenericPageVO<CustKeyDateVO> find(Page page, String sort, CustKeyDateQueryVO queryParam) {

        CustKeyDateQueryBean queryBean = BeanHelper.convertTo(queryParam,CustKeyDateQueryBean.class);
        queryBean.setOrderByStr(sort);
        Page<CustKeyDateEntity> entityPage = custKeyDateMapper.queryByPage(page, queryBean);
        List<CustKeyDateVO> custKeyDateVOS = new ArrayList<>();
        for (CustKeyDateEntity custKeyDateEntity : entityPage.getResults()) {
        CustKeyDateVO custKeyDateVO = BeanHelper.convertTo(custKeyDateEntity, CustKeyDateVO.class);
        custKeyDateVOS.add(custKeyDateVO);
        }
        return new GenericPageVO(entityPage.getTotalCount(), entityPage.getTotalPages(), custKeyDateVOS);
        }

/**
 * 根据ID查询客户重要日期
 * @param id
 * @return
 */
public CustKeyDateVO queryById(String id){
        CustKeyDateEntity entity = custKeyDateMapper.queryById(id);
        return BeanHelper.convertTo(entity,CustKeyDateVO.class);
        }

/**
 * 新增客户重要日期
 * @param custKeyDateVO
 */
public String insert(CustKeyDateVO custKeyDateVO){
        CustKeyDateEntity entity = BeanHelper.convertTo(custKeyDateVO,CustKeyDateEntity.class);
        entity.setdateId(UUID.randomUUID().toString());
        custKeyDateMapper.insert(entity);
        return entity.getdateId();
        }

/**
 * 更新客户重要日期
 * @param custKeyDateVO
 * @return
 */
public Boolean update(CustKeyDateVO custKeyDateVO){
        CustKeyDateEntity entity = BeanHelper.convertTo(custKeyDateVO,CustKeyDateEntity.class);
        return custKeyDateMapper.update(entity) == 1 ;
        }
        
/**
 * 删除客户重要日期
 * @param id
 * @return
 */
public Boolean delete(String id){
        return custKeyDateMapper.delete(id)==1;
        }

}
