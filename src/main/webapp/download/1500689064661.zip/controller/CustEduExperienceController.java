package com.longshare.cmsp.customer.management.controller;

        import com.longshare.cmsp.customer.management.ErrorCode;
        import com.longshare.cmsp.customer.management.model.CustEduExperienceQueryVO;
        import com.longshare.cmsp.customer.management.model.CustEduExperienceVO;
        import com.longshare.cmsp.customer.management.service.CustEduExperienceService;
        import com.longshare.cmsp.orm.support.model.Page;
        import com.longshare.cmsp.support.micro.service.api.result.GenericPageVO;
        import com.longshare.cmsp.support.micro.service.api.result.Result;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.web.bind.annotation.*;

/**
 * Created by WongCU.
 * 错误代码
 * CUSTEDUEXPERIENCE_ID_CANNOT_BE_NULL(1,"ID不能为空"),
 * CUSTEDUEXPERIENCE_CANNOT_BE_NULL(2,"教育经历不能为空"),
 * QUERY_CUSTEDUEXPERIENCE_BY_PAGE_ERROR(3,"分页查询教育经历发生异常"),
 * QUERY_CUSTEDUEXPERIENCE_DETAIL_ERROR(4,"查询教育经历详情发生异常"),
 * INSERT_CUSTEDUEXPERIENCE_ERROR(5,"新增教育经历发生异常"),
 * UPDATE_CUSTEDUEXPERIENCE_ERROR(6,"更新教育经历发生异常"),
 * DELETE_CUSTEDUEXPERIENCE_ERROR(7,"删除教育经历发生异常"),
 *
 */
@RestController
@RequestMapping("/api/custeduexperiences")
public class CustEduExperienceAPIController {
        Logger logger = LoggerFactory.getLogger(CustEduExperienceAPIController.class);

@Autowired
    CustEduExperienceService custEduExperienceService;

@PostMapping("/list")
public Result<GenericPageVO<CustEduExperienceVO>> list(@RequestParam(value = "page", required = false, defaultValue = "1") int pageNo,
@RequestParam(value = "rows", required = false, defaultValue = "10") int pageSize,
@RequestParam(value = "sort", required = false) String sort,
@RequestBody CustEduExperienceQueryVO queryVO) {
        logger.debug("根据查询条件分页查询教育经历信息,queryVO:{}",queryVO);
        try {
        return Result.genSuccessResult(custEduExperienceService.find(new Page(pageNo,pageSize),sort,queryVO));
        }catch (Exception e){
        logger.error("根据查询条件分页查询教育经历信息发生异常",e);
        System.out.println(e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.QUERY_CUSTEDUEXPERIENCE_BY_PAGE_ERROR.code,ErrorCode.QUERY_CUSTEDUEXPERIENCE_BY_PAGE_ERROR.message,e.getMessage());
        }
        }

@GetMapping("eduExperienceId")
public Result<CustEduExperienceVO> detail(@PathVariable("eduExperienceId") String eduExperienceId){
        logger.debug("根据ID查询教育经历详情信息,eduExperienceId:{}",eduExperienceId);
        if(eduExperienceId==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTEDUEXPERIENCE_ID_CANNOT_BE_NULL.code,ErrorCode.CUSTEDUEXPERIENCE_ID_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custEduExperienceService.queryById(eduExperienceId));
        }catch (Exception e){
        logger.error("根据客户ID查询教育经历信息发生异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.QUERY_CUSTEDUEXPERIENCE_DETAIL_ERROR.code,ErrorCode.QUERY_CUSTEDUEXPERIENCE_DETAIL_ERROR.message,null);
        }
        }

@PostMapping
public Result<String> create(@RequestBody CustEduExperienceVO custEduExperienceVO){
        logger.debug("新增教育经历,custEduExperienceVO:{}",custEduExperienceVO);
        if(custEduExperienceVO==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTEDUEXPERIENCE_CANNOT_BE_NULL.code,ErrorCode.CUSTEDUEXPERIENCE_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custEduExperienceService.insert(custEduExperienceVO));
        }catch (Exception e){
        logger.error("新增教育经历异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.INSERT_CUSTEDUEXPERIENCE_ERROR.code,ErrorCode.INSERT_CUSTEDUEXPERIENCE_ERROR.message,e.getMessage());
        }
        }

@PutMapping
public Result<Boolean> update(@RequestBody CustEduExperienceVO custEduExperienceVO){
        logger.debug("更新教育经历,custEduExperienceVO:{}",custEduExperienceVO);
        if(custEduExperienceVO==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTEDUEXPERIENCE_CANNOT_BE_NULL.code,ErrorCode.CUSTEDUEXPERIENCE_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custEduExperienceService.update(custEduExperienceVO));
        }catch (Exception e){
        logger.error("更新教育经历异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.UPDATE_CUSTEDUEXPERIENCE_ERROR.code,ErrorCode.UPDATE_CUSTEDUEXPERIENCE_ERROR.message,e.getMessage());
        }
        }

@DeleteMapping("/{id}")
public Result<Boolean> delete(@PathVariable("id") String id){
        logger.debug("根据ID删除教育经历,id:{}",id);
        if(id==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTEDUEXPERIENCE_ID_CANNOT_BE_NULL.code,ErrorCode.CUSTEDUEXPERIENCE_ID_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custEduExperienceService.delete(id));
        }catch (Exception e){
        logger.error("根据ID删除教育经历发生异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.DELETE_CUSTEDUEXPERIENCE_ERROR.code,ErrorCode.DELETE_CUSTEDUEXPERIENCE_ERROR.message,e.getMessage());
        }
        }
        }
