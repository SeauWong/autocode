package com.longshare.cmsp.customer.management.controller;

        import com.longshare.cmsp.customer.management.ErrorCode;
        import com.longshare.cmsp.customer.management.model.CustKeyDateQueryVO;
        import com.longshare.cmsp.customer.management.model.CustKeyDateVO;
        import com.longshare.cmsp.customer.management.service.CustKeyDateService;
        import com.longshare.cmsp.orm.support.model.Page;
        import com.longshare.cmsp.support.micro.service.api.result.GenericPageVO;
        import com.longshare.cmsp.support.micro.service.api.result.Result;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.web.bind.annotation.*;

/**
 * Created by WongCU.
 * 错误代码
 * CUSTKEYDATE_ID_CANNOT_BE_NULL(1,"ID不能为空"),
 * CUSTKEYDATE_CANNOT_BE_NULL(2,"客户重要日期不能为空"),
 * QUERY_CUSTKEYDATE_BY_PAGE_ERROR(3,"分页查询客户重要日期发生异常"),
 * QUERY_CUSTKEYDATE_DETAIL_ERROR(4,"查询客户重要日期详情发生异常"),
 * INSERT_CUSTKEYDATE_ERROR(5,"新增客户重要日期发生异常"),
 * UPDATE_CUSTKEYDATE_ERROR(6,"更新客户重要日期发生异常"),
 * DELETE_CUSTKEYDATE_ERROR(7,"删除客户重要日期发生异常"),
 *
 */
@RestController
@RequestMapping("/api/custkeydates")
public class CustKeyDateAPIController {
        Logger logger = LoggerFactory.getLogger(CustKeyDateAPIController.class);

@Autowired
    CustKeyDateService custKeyDateService;

@PostMapping("/list")
public Result<GenericPageVO<CustKeyDateVO>> list(@RequestParam(value = "page", required = false, defaultValue = "1") int pageNo,
@RequestParam(value = "rows", required = false, defaultValue = "10") int pageSize,
@RequestParam(value = "sort", required = false) String sort,
@RequestBody CustKeyDateQueryVO queryVO) {
        logger.debug("根据查询条件分页查询客户重要日期信息,queryVO:{}",queryVO);
        try {
        return Result.genSuccessResult(custKeyDateService.find(new Page(pageNo,pageSize),sort,queryVO));
        }catch (Exception e){
        logger.error("根据查询条件分页查询客户重要日期信息发生异常",e);
        System.out.println(e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.QUERY_CUSTKEYDATE_BY_PAGE_ERROR.code,ErrorCode.QUERY_CUSTKEYDATE_BY_PAGE_ERROR.message,e.getMessage());
        }
        }

@GetMapping("dateId")
public Result<CustKeyDateVO> detail(@PathVariable("dateId") String dateId){
        logger.debug("根据ID查询客户重要日期详情信息,dateId:{}",dateId);
        if(dateId==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTKEYDATE_ID_CANNOT_BE_NULL.code,ErrorCode.CUSTKEYDATE_ID_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custKeyDateService.queryById(dateId));
        }catch (Exception e){
        logger.error("根据客户ID查询客户重要日期信息发生异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.QUERY_CUSTKEYDATE_DETAIL_ERROR.code,ErrorCode.QUERY_CUSTKEYDATE_DETAIL_ERROR.message,null);
        }
        }

@PostMapping
public Result<String> create(@RequestBody CustKeyDateVO custKeyDateVO){
        logger.debug("新增客户重要日期,custKeyDateVO:{}",custKeyDateVO);
        if(custKeyDateVO==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTKEYDATE_CANNOT_BE_NULL.code,ErrorCode.CUSTKEYDATE_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custKeyDateService.insert(custKeyDateVO));
        }catch (Exception e){
        logger.error("新增客户重要日期异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.INSERT_CUSTKEYDATE_ERROR.code,ErrorCode.INSERT_CUSTKEYDATE_ERROR.message,e.getMessage());
        }
        }

@PutMapping
public Result<Boolean> update(@RequestBody CustKeyDateVO custKeyDateVO){
        logger.debug("更新客户重要日期,custKeyDateVO:{}",custKeyDateVO);
        if(custKeyDateVO==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTKEYDATE_CANNOT_BE_NULL.code,ErrorCode.CUSTKEYDATE_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custKeyDateService.update(custKeyDateVO));
        }catch (Exception e){
        logger.error("更新客户重要日期异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.UPDATE_CUSTKEYDATE_ERROR.code,ErrorCode.UPDATE_CUSTKEYDATE_ERROR.message,e.getMessage());
        }
        }

@DeleteMapping("/{id}")
public Result<Boolean> delete(@PathVariable("id") String id){
        logger.debug("根据ID删除客户重要日期,id:{}",id);
        if(id==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTKEYDATE_ID_CANNOT_BE_NULL.code,ErrorCode.CUSTKEYDATE_ID_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custKeyDateService.delete(id));
        }catch (Exception e){
        logger.error("根据ID删除客户重要日期发生异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.DELETE_CUSTKEYDATE_ERROR.code,ErrorCode.DELETE_CUSTKEYDATE_ERROR.message,e.getMessage());
        }
        }
        }
