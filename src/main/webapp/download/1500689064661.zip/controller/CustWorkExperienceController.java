package com.longshare.cmsp.customer.management.controller;

        import com.longshare.cmsp.customer.management.ErrorCode;
        import com.longshare.cmsp.customer.management.model.CustWorkExperienceQueryVO;
        import com.longshare.cmsp.customer.management.model.CustWorkExperienceVO;
        import com.longshare.cmsp.customer.management.service.CustWorkExperienceService;
        import com.longshare.cmsp.orm.support.model.Page;
        import com.longshare.cmsp.support.micro.service.api.result.GenericPageVO;
        import com.longshare.cmsp.support.micro.service.api.result.Result;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.web.bind.annotation.*;

/**
 * Created by WongCU.
 * 错误代码
 * CUSTWORKEXPERIENCE_ID_CANNOT_BE_NULL(1,"ID不能为空"),
 * CUSTWORKEXPERIENCE_CANNOT_BE_NULL(2,"工作经历不能为空"),
 * QUERY_CUSTWORKEXPERIENCE_BY_PAGE_ERROR(3,"分页查询工作经历发生异常"),
 * QUERY_CUSTWORKEXPERIENCE_DETAIL_ERROR(4,"查询工作经历详情发生异常"),
 * INSERT_CUSTWORKEXPERIENCE_ERROR(5,"新增工作经历发生异常"),
 * UPDATE_CUSTWORKEXPERIENCE_ERROR(6,"更新工作经历发生异常"),
 * DELETE_CUSTWORKEXPERIENCE_ERROR(7,"删除工作经历发生异常"),
 *
 */
@RestController
@RequestMapping("/api/custworkexperiences")
public class CustWorkExperienceAPIController {
        Logger logger = LoggerFactory.getLogger(CustWorkExperienceAPIController.class);

@Autowired
    CustWorkExperienceService custWorkExperienceService;

@PostMapping("/list")
public Result<GenericPageVO<CustWorkExperienceVO>> list(@RequestParam(value = "page", required = false, defaultValue = "1") int pageNo,
@RequestParam(value = "rows", required = false, defaultValue = "10") int pageSize,
@RequestParam(value = "sort", required = false) String sort,
@RequestBody CustWorkExperienceQueryVO queryVO) {
        logger.debug("根据查询条件分页查询工作经历信息,queryVO:{}",queryVO);
        try {
        return Result.genSuccessResult(custWorkExperienceService.find(new Page(pageNo,pageSize),sort,queryVO));
        }catch (Exception e){
        logger.error("根据查询条件分页查询工作经历信息发生异常",e);
        System.out.println(e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.QUERY_CUSTWORKEXPERIENCE_BY_PAGE_ERROR.code,ErrorCode.QUERY_CUSTWORKEXPERIENCE_BY_PAGE_ERROR.message,e.getMessage());
        }
        }

@GetMapping("workExperienceId")
public Result<CustWorkExperienceVO> detail(@PathVariable("workExperienceId") String workExperienceId){
        logger.debug("根据ID查询工作经历详情信息,workExperienceId:{}",workExperienceId);
        if(workExperienceId==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTWORKEXPERIENCE_ID_CANNOT_BE_NULL.code,ErrorCode.CUSTWORKEXPERIENCE_ID_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custWorkExperienceService.queryById(workExperienceId));
        }catch (Exception e){
        logger.error("根据客户ID查询工作经历信息发生异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.QUERY_CUSTWORKEXPERIENCE_DETAIL_ERROR.code,ErrorCode.QUERY_CUSTWORKEXPERIENCE_DETAIL_ERROR.message,null);
        }
        }

@PostMapping
public Result<String> create(@RequestBody CustWorkExperienceVO custWorkExperienceVO){
        logger.debug("新增工作经历,custWorkExperienceVO:{}",custWorkExperienceVO);
        if(custWorkExperienceVO==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTWORKEXPERIENCE_CANNOT_BE_NULL.code,ErrorCode.CUSTWORKEXPERIENCE_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custWorkExperienceService.insert(custWorkExperienceVO));
        }catch (Exception e){
        logger.error("新增工作经历异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.INSERT_CUSTWORKEXPERIENCE_ERROR.code,ErrorCode.INSERT_CUSTWORKEXPERIENCE_ERROR.message,e.getMessage());
        }
        }

@PutMapping
public Result<Boolean> update(@RequestBody CustWorkExperienceVO custWorkExperienceVO){
        logger.debug("更新工作经历,custWorkExperienceVO:{}",custWorkExperienceVO);
        if(custWorkExperienceVO==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTWORKEXPERIENCE_CANNOT_BE_NULL.code,ErrorCode.CUSTWORKEXPERIENCE_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custWorkExperienceService.update(custWorkExperienceVO));
        }catch (Exception e){
        logger.error("更新工作经历异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.UPDATE_CUSTWORKEXPERIENCE_ERROR.code,ErrorCode.UPDATE_CUSTWORKEXPERIENCE_ERROR.message,e.getMessage());
        }
        }

@DeleteMapping("/{id}")
public Result<Boolean> delete(@PathVariable("id") String id){
        logger.debug("根据ID删除工作经历,id:{}",id);
        if(id==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTWORKEXPERIENCE_ID_CANNOT_BE_NULL.code,ErrorCode.CUSTWORKEXPERIENCE_ID_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custWorkExperienceService.delete(id));
        }catch (Exception e){
        logger.error("根据ID删除工作经历发生异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.DELETE_CUSTWORKEXPERIENCE_ERROR.code,ErrorCode.DELETE_CUSTWORKEXPERIENCE_ERROR.message,e.getMessage());
        }
        }
        }
