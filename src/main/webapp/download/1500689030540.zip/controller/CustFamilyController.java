package com.longshare.cmsp.customer.management.controller;

        import com.longshare.cmsp.customer.management.ErrorCode;
        import com.longshare.cmsp.customer.management.model.CustFamilyQueryVO;
        import com.longshare.cmsp.customer.management.model.CustFamilyVO;
        import com.longshare.cmsp.customer.management.service.CustFamilyService;
        import com.longshare.cmsp.orm.support.model.Page;
        import com.longshare.cmsp.support.micro.service.api.result.GenericPageVO;
        import com.longshare.cmsp.support.micro.service.api.result.Result;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.web.bind.annotation.*;

/**
 * Created by WongCU.
 * 错误代码
 * CUSTFAMILY_ID_CANNOT_BE_NULL(1,"ID不能为空"),
 * CUSTFAMILY_CANNOT_BE_NULL(2,"家庭成员不能为空"),
 * QUERY_CUSTFAMILY_BY_PAGE_ERROR(3,"分页查询家庭成员发生异常"),
 * QUERY_CUSTFAMILY_DETAIL_ERROR(4,"查询家庭成员详情发生异常"),
 * INSERT_CUSTFAMILY_ERROR(5,"新增家庭成员发生异常"),
 * UPDATE_CUSTFAMILY_ERROR(6,"更新家庭成员发生异常"),
 * DELETE_CUSTFAMILY_ERROR(7,"删除家庭成员发生异常"),
 *
 */
@RestController
@RequestMapping("/api/custfamilys")
public class CustFamilyAPIController {
        Logger logger = LoggerFactory.getLogger(CustFamilyAPIController.class);

@Autowired
    CustFamilyService custFamilyService;

@PostMapping("/list")
public Result<GenericPageVO<CustFamilyVO>> list(@RequestParam(value = "page", required = false, defaultValue = "1") int pageNo,
@RequestParam(value = "rows", required = false, defaultValue = "10") int pageSize,
@RequestParam(value = "sort", required = false) String sort,
@RequestBody CustFamilyQueryVO queryVO) {
        logger.debug("根据查询条件分页查询家庭成员信息,queryVO:{}",queryVO);
        try {
        return Result.genSuccessResult(custFamilyService.find(new Page(pageNo,pageSize),sort,queryVO));
        }catch (Exception e){
        logger.error("根据查询条件分页查询家庭成员信息发生异常",e);
        System.out.println(e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.QUERY_CUSTFAMILY_BY_PAGE_ERROR.code,ErrorCode.QUERY_CUSTFAMILY_BY_PAGE_ERROR.message,e.getMessage());
        }
        }

@GetMapping("familyId")
public Result<CustFamilyVO> detail(@PathVariable("familyId") String familyId){
        logger.debug("根据ID查询家庭成员详情信息,familyId:{}",familyId);
        if(familyId==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTFAMILY_ID_CANNOT_BE_NULL.code,ErrorCode.CUSTFAMILY_ID_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custFamilyService.queryById(familyId));
        }catch (Exception e){
        logger.error("根据客户ID查询家庭成员信息发生异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.QUERY_CUSTFAMILY_DETAIL_ERROR.code,ErrorCode.QUERY_CUSTFAMILY_DETAIL_ERROR.message,null);
        }
        }

@PostMapping
public Result<String> create(@RequestBody CustFamilyVO custFamilyVO){
        logger.debug("新增家庭成员,custFamilyVO:{}",custFamilyVO);
        if(custFamilyVO==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTFAMILY_CANNOT_BE_NULL.code,ErrorCode.CUSTFAMILY_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custFamilyService.insert(custFamilyVO));
        }catch (Exception e){
        logger.error("新增家庭成员异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.INSERT_CUSTFAMILY_ERROR.code,ErrorCode.INSERT_CUSTFAMILY_ERROR.message,e.getMessage());
        }
        }

@PutMapping
public Result<Boolean> update(@RequestBody CustFamilyVO custFamilyVO){
        logger.debug("更新家庭成员,custFamilyVO:{}",custFamilyVO);
        if(custFamilyVO==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTFAMILY_CANNOT_BE_NULL.code,ErrorCode.CUSTFAMILY_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custFamilyService.update(custFamilyVO));
        }catch (Exception e){
        logger.error("更新家庭成员异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.UPDATE_CUSTFAMILY_ERROR.code,ErrorCode.UPDATE_CUSTFAMILY_ERROR.message,e.getMessage());
        }
        }

@DeleteMapping("/{id}")
public Result<Boolean> delete(@PathVariable("id") String id){
        logger.debug("根据ID删除家庭成员,id:{}",id);
        if(id==null){
        return Result.genFailResult(ErrorCode.appCode,ErrorCode.CUSTFAMILY_ID_CANNOT_BE_NULL.code,ErrorCode.CUSTFAMILY_ID_CANNOT_BE_NULL.message,null);
        }
        try {
        return Result.genSuccessResult(custFamilyService.delete(id));
        }catch (Exception e){
        logger.error("根据ID删除家庭成员发生异常",e);
        return Result.genErrorResult(ErrorCode.appCode,ErrorCode.DELETE_CUSTFAMILY_ERROR.code,ErrorCode.DELETE_CUSTFAMILY_ERROR.message,e.getMessage());
        }
        }
        }
