        package com.longshare.cmsp.customer.management.orm.entity;
        import java.io.Serializable;
        import java.sql.Timestamp;
        import java.util.*;
/**
 工作经历
 */
public class CustWorkExperienceEntity implements Serializable{
private static final long serialVersionUID = 1L;
        /**
 * 
 */
private String workExperienceId;
        /**
 * ID
 */
private String customerId;
        /**
 * 公司名称
 */
private String companyName;
        /**
 * 公司性质
 */
private String companyType;
        /**
 * 职务（字典）
 */
private String duty;
        /**
 * 开始时间
 */
private Date beginDate;
        /**
 * 结束时间
 */
private Date endDate;
                }