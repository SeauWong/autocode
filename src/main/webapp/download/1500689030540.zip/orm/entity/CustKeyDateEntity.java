        package com.longshare.cmsp.customer.management.orm.entity;
        import java.io.Serializable;
        import java.sql.Timestamp;
        import java.util.*;
/**
 客户重要日期
 */
public class CustKeyDateEntity implements Serializable{
private static final long serialVersionUID = 1L;
        /**
 * 
 */
private String dateId;
        /**
 * ID
 */
private String customerId;
        /**
 * 时间
 */
private Date keyDate;
        /**
 * 名称
 */
private String name;
        /**
 * 描述
 */
private String description;
                }