        package com.longshare.cmsp.customer.management.orm.entity;
        import java.io.Serializable;
        import java.sql.Timestamp;
        import java.util.*;
/**
 教育经历
 */
public class CustEduExperienceEntity implements Serializable{
private static final long serialVersionUID = 1L;
        /**
 * 
 */
private String eduExperienceId;
        /**
 * ID
 */
private String customerId;
        /**
 * 学校
 */
private String schoolName;
        /**
 * 学校类型
 */
private String schoolType;
        /**
 * 开始时间
 */
private Date beginDate;
        /**
 * 结束时间
 */
private Date endDate;
                }