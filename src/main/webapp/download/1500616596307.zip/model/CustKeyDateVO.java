package com.longshare.cmsp.customer.management.model;
        import java.io.Serializable;
        import java.util.*;
/**
 * Create By WongCU
 */
public class CustKeyDateVO implements Serializable{
private static final long serialVersionUID=1L;
                /**
 * 
 */
private String dateId;
                        /**
 * ID
 */
private String customerId;
                        /**
 * 时间
 */
private Date keyDate;
                        /**
 * 名称
 */
private String name;
                        /**
 * 描述
 */
private String description;
                /**
 * orderBy
 */
private String orderByStr;

private String queryParam;
        }