package com.longshare.cmsp.customer.management.model;
        import java.io.Serializable;
        import java.util.*;
/**
 * Create By WongCU
 */
public class CustRCustomerTagVO implements Serializable{
private static final long serialVersionUID=1L;
                /**
 * 
 */
private String tagId;
                        /**
 * ID
 */
private String customerId;
                /**
 * orderBy
 */
private String orderByStr;

private String queryParam;
        }