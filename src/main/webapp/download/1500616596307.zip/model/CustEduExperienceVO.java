package com.longshare.cmsp.customer.management.model;
        import java.io.Serializable;
        import java.util.*;
/**
 * Create By WongCU
 */
public class CustEduExperienceVO implements Serializable{
private static final long serialVersionUID=1L;
                /**
 * 
 */
private String eduExperienceId;
                        /**
 * ID
 */
private String customerId;
                        /**
 * 学校
 */
private String schoolName;
                        /**
 * 学校类型
 */
private String schoolType;
                        /**
 * 开始时间
 */
private Date beginDate;
                        /**
 * 结束时间
 */
private Date endDate;
                /**
 * orderBy
 */
private String orderByStr;

private String queryParam;
        }