        package com.longshare.cmsp.customer.management.orm.entity;
        import java.io.Serializable;
        import java.sql.Timestamp;
        import java.util.*;
/**
 家庭成员
 */
public class CustFamilyEntity implements Serializable{
private static final long serialVersionUID = 1L;
        /**
 * 
 */
private String familyId;
        /**
 * ID
 */
private String customerId;
        /**
 * 名称
 */
private String name;
        /**
 * 手机号码
 */
private String mobile;
        /**
 * 
 */
private String relationship;
        /**
 * 职业（字典）
 */
private String vocation;
        /**
 * 生日
 */
private String birthday;
                }