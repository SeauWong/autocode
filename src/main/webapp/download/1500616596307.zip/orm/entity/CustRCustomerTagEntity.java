        package com.longshare.cmsp.customer.management.orm.entity;
        import java.io.Serializable;
        import java.sql.Timestamp;
        import java.util.*;
/**
 客户标签关系
 */
public class CustRCustomerTagEntity implements Serializable{
private static final long serialVersionUID = 1L;
        /**
 * 
 */
private String tagId;
        /**
 * ID
 */
private String customerId;
                }