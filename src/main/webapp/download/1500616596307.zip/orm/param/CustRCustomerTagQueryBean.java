package com.longshare.cmsp.customer.management.orm.param;
import java.io.Serializable;
import java.sql.*;
import java.util.*;
import java.util.Date;
/**
 客户标签关系
 */
public class CustRCustomerTagQueryBean implements Serializable{
private static final long serialVersionUID = 1L;
        
        /**
 * 
 */
private String tagId;
                
        /**
 * ID
 */
private String customerId;
                /**
 * orderBy
 */
private String orderByStr;

private String queryParam;
        }