package com.longshare.cmsp.customer.management.orm.param;
import java.io.Serializable;
import java.sql.*;
import java.util.*;
import java.util.Date;
/**
 客户重要日期
 */
public class CustKeyDateQueryBean implements Serializable{
private static final long serialVersionUID = 1L;
        
        /**
 * 
 */
private String dateId;
                
        /**
 * ID
 */
private String customerId;
                
        /**
 * 时间
 */
private Date keyDate;
                
        /**
 * 名称
 */
private String name;
                
        /**
 * 描述
 */
private String description;
                /**
 * orderBy
 */
private String orderByStr;

private String queryParam;
        }