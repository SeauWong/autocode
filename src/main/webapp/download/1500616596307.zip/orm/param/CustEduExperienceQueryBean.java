package com.longshare.cmsp.customer.management.orm.param;
import java.io.Serializable;
import java.sql.*;
import java.util.*;
import java.util.Date;
/**
 教育经历
 */
public class CustEduExperienceQueryBean implements Serializable{
private static final long serialVersionUID = 1L;
        
        /**
 * 
 */
private String eduExperienceId;
                
        /**
 * ID
 */
private String customerId;
                
        /**
 * 学校
 */
private String schoolName;
                
        /**
 * 学校类型
 */
private String schoolType;
                
        /**
 * 开始时间
 */
private Date beginDate;
                
        /**
 * 结束时间
 */
private Date endDate;
                /**
 * orderBy
 */
private String orderByStr;

private String queryParam;
        }