package com.longshare.cmsp.customer.management.orm.param;
import java.io.Serializable;
import java.sql.*;
import java.util.*;
import java.util.Date;
/**
 家庭成员
 */
public class CustFamilyQueryBean implements Serializable{
private static final long serialVersionUID = 1L;
        
        /**
 * 
 */
private String familyId;
                
        /**
 * ID
 */
private String customerId;
                
        /**
 * 名称
 */
private String name;
                
        /**
 * 手机号码
 */
private String mobile;
                
        /**
 * 
 */
private String relationship;
                
        /**
 * 职业（字典）
 */
private String vocation;
                
        /**
 * 生日
 */
private String birthday;
                /**
 * orderBy
 */
private String orderByStr;

private String queryParam;
        }