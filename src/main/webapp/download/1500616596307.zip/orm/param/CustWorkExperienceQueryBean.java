package com.longshare.cmsp.customer.management.orm.param;
import java.io.Serializable;
import java.sql.*;
import java.util.*;
import java.util.Date;
/**
 工作经历
 */
public class CustWorkExperienceQueryBean implements Serializable{
private static final long serialVersionUID = 1L;
        
        /**
 * 
 */
private String workExperienceId;
                
        /**
 * ID
 */
private String customerId;
                
        /**
 * 公司名称
 */
private String companyName;
                
        /**
 * 公司性质
 */
private String companyType;
                
        /**
 * 职务（字典）
 */
private String duty;
                
        /**
 * 开始时间
 */
private Date beginDate;
                
        /**
 * 结束时间
 */
private Date endDate;
                /**
 * orderBy
 */
private String orderByStr;

private String queryParam;
        }