package com.longshare.cmsp.customer.management.orm.mapper;

import com.longshare.cmsp.customer.management.orm.entity.MemberEntity;
import com.longshare.cmsp.customer.management.orm.param.MemberQueryBean;
import com.longshare.cmsp.orm.support.model.Page;

import java.util.List;

public interface CustWorkExperienceMapper {
    int delete(String id);

    int insert(CustWorkExperienceEntity entity);

    MemberEntity queryById(String id);

    List<CustWorkExperienceEntity> query(CustWorkExperienceQueryBean queryBean);

    int update(CustWorkExperienceEntity entity);

    Page<CustWorkExperienceEntity> queryByPage(Page<CustWorkExperienceEntity> page, CustWorkExperienceQueryBean queryBean);
}
