package com.longshare.cmsp.customer.management.orm.mapper;

import com.longshare.cmsp.customer.management.orm.entity.MemberEntity;
import com.longshare.cmsp.customer.management.orm.param.MemberQueryBean;
import com.longshare.cmsp.orm.support.model.Page;

import java.util.List;

public interface CustEduExperienceMapper {
    int delete(String id);

    int insert(CustEduExperienceEntity entity);

    MemberEntity queryById(String id);

    List<CustEduExperienceEntity> query(CustEduExperienceQueryBean queryBean);

    int update(CustEduExperienceEntity entity);

    Page<CustEduExperienceEntity> queryByPage(Page<CustEduExperienceEntity> page, CustEduExperienceQueryBean queryBean);
}
