package com.longshare.cmsp.customer.management.orm.mapper;

import com.longshare.cmsp.customer.management.orm.entity.MemberEntity;
import com.longshare.cmsp.customer.management.orm.param.MemberQueryBean;
import com.longshare.cmsp.orm.support.model.Page;

import java.util.List;

public interface CustRCustomerTagMapper {
    int delete(String id);

    int insert(CustRCustomerTagEntity entity);

    MemberEntity queryById(String id);

    List<CustRCustomerTagEntity> query(CustRCustomerTagQueryBean queryBean);

    int update(CustRCustomerTagEntity entity);

    Page<CustRCustomerTagEntity> queryByPage(Page<CustRCustomerTagEntity> page, CustRCustomerTagQueryBean queryBean);
}
