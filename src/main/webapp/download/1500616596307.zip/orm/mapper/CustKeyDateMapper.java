package com.longshare.cmsp.customer.management.orm.mapper;

import com.longshare.cmsp.customer.management.orm.entity.MemberEntity;
import com.longshare.cmsp.customer.management.orm.param.MemberQueryBean;
import com.longshare.cmsp.orm.support.model.Page;

import java.util.List;

public interface CustKeyDateMapper {
    int delete(String id);

    int insert(CustKeyDateEntity entity);

    MemberEntity queryById(String id);

    List<CustKeyDateEntity> query(CustKeyDateQueryBean queryBean);

    int update(CustKeyDateEntity entity);

    Page<CustKeyDateEntity> queryByPage(Page<CustKeyDateEntity> page, CustKeyDateQueryBean queryBean);
}
