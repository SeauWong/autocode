package com.longshare.cmsp.customer.management.orm.mapper;

import com.longshare.cmsp.customer.management.orm.entity.MemberEntity;
import com.longshare.cmsp.customer.management.orm.param.MemberQueryBean;
import com.longshare.cmsp.orm.support.model.Page;

import java.util.List;

public interface CustFamilyMapper {
    int delete(String id);

    int insert(CustFamilyEntity entity);

    MemberEntity queryById(String id);

    List<CustFamilyEntity> query(CustFamilyQueryBean queryBean);

    int update(CustFamilyEntity entity);

    Page<CustFamilyEntity> queryByPage(Page<CustFamilyEntity> page, CustFamilyQueryBean queryBean);
}
