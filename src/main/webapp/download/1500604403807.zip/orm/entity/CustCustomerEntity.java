package com.longshare.cmsp.customer.management.orm.entity;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.*;
/**
 客户
 */
public class CustCustomerEntity implement Serializable{
private static final long serialVersionUID = 1L;
        /**
 * ID
 */
private String customerId;
        /**
 * 名称
 */
private String name;
        /**
 * 名称拼音
 */
private String pinyin;
        /**
 * 类型(字典)
 */
private String type;
        /**
 * 证件类型(字典)
 */
private String iDType;
        /**
 * 证件号码
 */
private String iDNumber;
        /**
 * 证件有效期：yyyymmdd格式
 */
private String iDExpireationDate;
        /**
 * 手机号码
 */
private String mobile;
        /**
 * 电话
 */
private String telephone;
        /**
 * 状态（字典）
 */
private String status;
        /**
 * 投资者类型，专业or普通（字典）
 */
private String investorType;
        /**
 * 理财师ID
 */
private String employeeId;
        /**
 * 国籍(字典)
 */
private String nationality;
        /**
 * 生日
 */
private String birthday;
        /**
 * 性别(字典)
 */
private String gender;
        /**
 * 区域代码参考plat_area表定义(字典)
 */
private String areaCode;
        /**
 * 城市代码对应的城市组合名称+具体地址
 */
private String address;
        /**
 * 职业（字典）
 */
private String vocation;
        /**
 * 学历（字典）
 */
private String education;
        /**
 * 职务（字典）
 */
private String duty;
        /**
 * 邮编
 */
private String zipcode;
        /**
 * 传真号码
 */
private String faxNo;
        /**
 * 电子邮箱
 */
private String email;
        /**
 * QQ号码
 */
private String qq;
        /**
 * 经办人证件类型(字典)
 */
private String contactIDType;
        /**
 * 经办人证件号码
 */
private String contactIDNumber;
        /**
 * 经办人名称
 */
private String contactName;
        /**
 * 经办人手机号码
 */
private String contactMobile;
        /**
 * 经办人邮箱
 */
private String contactEmail;
        /**
 * 经办人联系地址
 */
private String contactAddress;
        /**
 * 法人名称
 */
private String legalName;
        /**
 * 法人证件类型(字典)
 */
private String legalIDType;
        /**
 * 法人证件号码
 */
private String legalIDNumber;
        /**
 * 机构类型（字典）
 */
private String organizationType;
        /**
 * 来源(字典)
 */
private String source;
        /**
 * 推荐人
 */
private String referee;
        /**
 * 会员状态(字典)
 */
private String memberStatus;
        /**
 * 入会时间
 */
private Date memberTime;
        /**
 * 合格投资者状态(字典)
 */
private String quaifiedInvestorStatus;
        /**
 * 合格投资者时间
 */
private Date qualifedInvestorTime;
        /**
 * 投资状态(字典)
 */
private String investStatus;
        /**
 * 风险评测状态(字典)
 */
private String riskStatus;
        /**
 * 风险承受能力（字典）
 */
private Integer riskLevel;
        /**
 * 风险评测时间
 */
private Date riskTime;
        /**
 * 描述
 */
private String description;
        /**
 * 投资偏好（字典）
 */
private String investPreference;
        /**
 * 投资目的（字典）
 */
private String investPurpose;
        /**
 * 投资潜力（字典）
 */
private String investPotential;
        /**
 * 沟通意愿（字典）
 */
private String communicationWill;
        /**
 * 沟通方式偏好（字典）
 */
private String communicationType;
        /**
 * 礼品偏好（字典）
 */
private String giftPreference;
        /**
 * 活动偏好（字典）
 */
private String activityPreference;
        /**
 * 个人年收入（字典）
 */
private String personalIncome;
        /**
 * 家庭年收入（字典）
 */
private String householdIncome;
        /**
 * 标签集（多个以应为逗号分隔）
 */
private String tags;
        /**
 * 创建时间
 */
private Date createdTime;
        /**
 * 创建人
 */
private String creater;
        /**
 * 修改时间
 */
private Date modifiedTime;
        /**
 * 修改人
 */
private String modifier;
        
        public void setCustomerId(String customerId){
        this.customerId = customerId;
        }

public String getCustomerId(){
        return this.customerId;
        }

        public void setName(String name){
        this.name = name;
        }

public String getName(){
        return this.name;
        }

        public void setPinyin(String pinyin){
        this.pinyin = pinyin;
        }

public String getPinyin(){
        return this.pinyin;
        }

        public void setType(String type){
        this.type = type;
        }

public String getType(){
        return this.type;
        }

        public void setIDType(String iDType){
        this.iDType = iDType;
        }

public String getIDType(){
        return this.iDType;
        }

        public void setIDNumber(String iDNumber){
        this.iDNumber = iDNumber;
        }

public String getIDNumber(){
        return this.iDNumber;
        }

        public void setIDExpireationDate(String iDExpireationDate){
        this.iDExpireationDate = iDExpireationDate;
        }

public String getIDExpireationDate(){
        return this.iDExpireationDate;
        }

        public void setMobile(String mobile){
        this.mobile = mobile;
        }

public String getMobile(){
        return this.mobile;
        }

        public void setTelephone(String telephone){
        this.telephone = telephone;
        }

public String getTelephone(){
        return this.telephone;
        }

        public void setStatus(String status){
        this.status = status;
        }

public String getStatus(){
        return this.status;
        }

        public void setInvestorType(String investorType){
        this.investorType = investorType;
        }

public String getInvestorType(){
        return this.investorType;
        }

        public void setEmployeeId(String employeeId){
        this.employeeId = employeeId;
        }

public String getEmployeeId(){
        return this.employeeId;
        }

        public void setNationality(String nationality){
        this.nationality = nationality;
        }

public String getNationality(){
        return this.nationality;
        }

        public void setBirthday(String birthday){
        this.birthday = birthday;
        }

public String getBirthday(){
        return this.birthday;
        }

        public void setGender(String gender){
        this.gender = gender;
        }

public String getGender(){
        return this.gender;
        }

        public void setAreaCode(String areaCode){
        this.areaCode = areaCode;
        }

public String getAreaCode(){
        return this.areaCode;
        }

        public void setAddress(String address){
        this.address = address;
        }

public String getAddress(){
        return this.address;
        }

        public void setVocation(String vocation){
        this.vocation = vocation;
        }

public String getVocation(){
        return this.vocation;
        }

        public void setEducation(String education){
        this.education = education;
        }

public String getEducation(){
        return this.education;
        }

        public void setDuty(String duty){
        this.duty = duty;
        }

public String getDuty(){
        return this.duty;
        }

        public void setZipcode(String zipcode){
        this.zipcode = zipcode;
        }

public String getZipcode(){
        return this.zipcode;
        }

        public void setFaxNo(String faxNo){
        this.faxNo = faxNo;
        }

public String getFaxNo(){
        return this.faxNo;
        }

        public void setEmail(String email){
        this.email = email;
        }

public String getEmail(){
        return this.email;
        }

        public void setQq(String qq){
        this.qq = qq;
        }

public String getQq(){
        return this.qq;
        }

        public void setContactIDType(String contactIDType){
        this.contactIDType = contactIDType;
        }

public String getContactIDType(){
        return this.contactIDType;
        }

        public void setContactIDNumber(String contactIDNumber){
        this.contactIDNumber = contactIDNumber;
        }

public String getContactIDNumber(){
        return this.contactIDNumber;
        }

        public void setContactName(String contactName){
        this.contactName = contactName;
        }

public String getContactName(){
        return this.contactName;
        }

        public void setContactMobile(String contactMobile){
        this.contactMobile = contactMobile;
        }

public String getContactMobile(){
        return this.contactMobile;
        }

        public void setContactEmail(String contactEmail){
        this.contactEmail = contactEmail;
        }

public String getContactEmail(){
        return this.contactEmail;
        }

        public void setContactAddress(String contactAddress){
        this.contactAddress = contactAddress;
        }

public String getContactAddress(){
        return this.contactAddress;
        }

        public void setLegalName(String legalName){
        this.legalName = legalName;
        }

public String getLegalName(){
        return this.legalName;
        }

        public void setLegalIDType(String legalIDType){
        this.legalIDType = legalIDType;
        }

public String getLegalIDType(){
        return this.legalIDType;
        }

        public void setLegalIDNumber(String legalIDNumber){
        this.legalIDNumber = legalIDNumber;
        }

public String getLegalIDNumber(){
        return this.legalIDNumber;
        }

        public void setOrganizationType(String organizationType){
        this.organizationType = organizationType;
        }

public String getOrganizationType(){
        return this.organizationType;
        }

        public void setSource(String source){
        this.source = source;
        }

public String getSource(){
        return this.source;
        }

        public void setReferee(String referee){
        this.referee = referee;
        }

public String getReferee(){
        return this.referee;
        }

        public void setMemberStatus(String memberStatus){
        this.memberStatus = memberStatus;
        }

public String getMemberStatus(){
        return this.memberStatus;
        }

        public void setMemberTime(Date memberTime){
        this.memberTime = memberTime;
        }

public Date getMemberTime(){
        return this.memberTime;
        }

        public void setQuaifiedInvestorStatus(String quaifiedInvestorStatus){
        this.quaifiedInvestorStatus = quaifiedInvestorStatus;
        }

public String getQuaifiedInvestorStatus(){
        return this.quaifiedInvestorStatus;
        }

        public void setQualifedInvestorTime(Date qualifedInvestorTime){
        this.qualifedInvestorTime = qualifedInvestorTime;
        }

public Date getQualifedInvestorTime(){
        return this.qualifedInvestorTime;
        }

        public void setInvestStatus(String investStatus){
        this.investStatus = investStatus;
        }

public String getInvestStatus(){
        return this.investStatus;
        }

        public void setRiskStatus(String riskStatus){
        this.riskStatus = riskStatus;
        }

public String getRiskStatus(){
        return this.riskStatus;
        }

        public void setRiskLevel(Integer riskLevel){
        this.riskLevel = riskLevel;
        }

public Integer getRiskLevel(){
        return this.riskLevel;
        }

        public void setRiskTime(Date riskTime){
        this.riskTime = riskTime;
        }

public Date getRiskTime(){
        return this.riskTime;
        }

        public void setDescription(String description){
        this.description = description;
        }

public String getDescription(){
        return this.description;
        }

        public void setInvestPreference(String investPreference){
        this.investPreference = investPreference;
        }

public String getInvestPreference(){
        return this.investPreference;
        }

        public void setInvestPurpose(String investPurpose){
        this.investPurpose = investPurpose;
        }

public String getInvestPurpose(){
        return this.investPurpose;
        }

        public void setInvestPotential(String investPotential){
        this.investPotential = investPotential;
        }

public String getInvestPotential(){
        return this.investPotential;
        }

        public void setCommunicationWill(String communicationWill){
        this.communicationWill = communicationWill;
        }

public String getCommunicationWill(){
        return this.communicationWill;
        }

        public void setCommunicationType(String communicationType){
        this.communicationType = communicationType;
        }

public String getCommunicationType(){
        return this.communicationType;
        }

        public void setGiftPreference(String giftPreference){
        this.giftPreference = giftPreference;
        }

public String getGiftPreference(){
        return this.giftPreference;
        }

        public void setActivityPreference(String activityPreference){
        this.activityPreference = activityPreference;
        }

public String getActivityPreference(){
        return this.activityPreference;
        }

        public void setPersonalIncome(String personalIncome){
        this.personalIncome = personalIncome;
        }

public String getPersonalIncome(){
        return this.personalIncome;
        }

        public void setHouseholdIncome(String householdIncome){
        this.householdIncome = householdIncome;
        }

public String getHouseholdIncome(){
        return this.householdIncome;
        }

        public void setTags(String tags){
        this.tags = tags;
        }

public String getTags(){
        return this.tags;
        }

        public void setCreatedTime(Date createdTime){
        this.createdTime = createdTime;
        }

public Date getCreatedTime(){
        return this.createdTime;
        }

        public void setCreater(String creater){
        this.creater = creater;
        }

public String getCreater(){
        return this.creater;
        }

        public void setModifiedTime(Date modifiedTime){
        this.modifiedTime = modifiedTime;
        }

public Date getModifiedTime(){
        return this.modifiedTime;
        }

        public void setModifier(String modifier){
        this.modifier = modifier;
        }

public String getModifier(){
        return this.modifier;
        }

        @Override
public String toString(){
    return "CustCustomerEntity"+
            "customerId='" + customerId + '\'' +
            "name='" + name + '\'' +
            "pinyin='" + pinyin + '\'' +
            "type='" + type + '\'' +
            "iDType='" + iDType + '\'' +
            "iDNumber='" + iDNumber + '\'' +
            "iDExpireationDate='" + iDExpireationDate + '\'' +
            "mobile='" + mobile + '\'' +
            "telephone='" + telephone + '\'' +
            "status='" + status + '\'' +
            "investorType='" + investorType + '\'' +
            "employeeId='" + employeeId + '\'' +
            "nationality='" + nationality + '\'' +
            "birthday='" + birthday + '\'' +
            "gender='" + gender + '\'' +
            "areaCode='" + areaCode + '\'' +
            "address='" + address + '\'' +
            "vocation='" + vocation + '\'' +
            "education='" + education + '\'' +
            "duty='" + duty + '\'' +
            "zipcode='" + zipcode + '\'' +
            "faxNo='" + faxNo + '\'' +
            "email='" + email + '\'' +
            "qq='" + qq + '\'' +
            "contactIDType='" + contactIDType + '\'' +
            "contactIDNumber='" + contactIDNumber + '\'' +
            "contactName='" + contactName + '\'' +
            "contactMobile='" + contactMobile + '\'' +
            "contactEmail='" + contactEmail + '\'' +
            "contactAddress='" + contactAddress + '\'' +
            "legalName='" + legalName + '\'' +
            "legalIDType='" + legalIDType + '\'' +
            "legalIDNumber='" + legalIDNumber + '\'' +
            "organizationType='" + organizationType + '\'' +
            "source='" + source + '\'' +
            "referee='" + referee + '\'' +
            "memberStatus='" + memberStatus + '\'' +
            "memberTime='" + memberTime + '\'' +
            "quaifiedInvestorStatus='" + quaifiedInvestorStatus + '\'' +
            "qualifedInvestorTime='" + qualifedInvestorTime + '\'' +
            "investStatus='" + investStatus + '\'' +
            "riskStatus='" + riskStatus + '\'' +
            "riskLevel='" + riskLevel + '\'' +
            "riskTime='" + riskTime + '\'' +
            "description='" + description + '\'' +
            "investPreference='" + investPreference + '\'' +
            "investPurpose='" + investPurpose + '\'' +
            "investPotential='" + investPotential + '\'' +
            "communicationWill='" + communicationWill + '\'' +
            "communicationType='" + communicationType + '\'' +
            "giftPreference='" + giftPreference + '\'' +
            "activityPreference='" + activityPreference + '\'' +
            "personalIncome='" + personalIncome + '\'' +
            "householdIncome='" + householdIncome + '\'' +
            "tags='" + tags + '\'' +
            "createdTime='" + createdTime + '\'' +
            "creater='" + creater + '\'' +
            "modifiedTime='" + modifiedTime + '\'' +
            "modifier='" + modifier + '\'' +
        '}';
}
}