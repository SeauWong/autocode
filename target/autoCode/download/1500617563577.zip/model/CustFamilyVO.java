package com.longshare.cmsp.customer.management.model;
        import java.io.Serializable;
        import java.util.*;
/**
 * Create By WongCU
 */
public class CustFamilyVO implements Serializable{
private static final long serialVersionUID=1L;
                /**
 * 
 */
private String familyId;
                        /**
 * ID
 */
private String customerId;
                        /**
 * 名称
 */
private String name;
                        /**
 * 手机号码
 */
private String mobile;
                        /**
 * 
 */
private String relationship;
                        /**
 * 职业（字典）
 */
private String vocation;

/**
 * 职业（字典）(文本)
 */
private String vocation_text;
                        /**
 * 生日
 */
private String birthday;
                /**
 * orderBy
 */
private String orderByStr;

private String queryParam;
        }