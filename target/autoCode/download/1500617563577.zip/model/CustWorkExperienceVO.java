package com.longshare.cmsp.customer.management.model;
        import java.io.Serializable;
        import java.util.*;
/**
 * Create By WongCU
 */
public class CustWorkExperienceVO implements Serializable{
private static final long serialVersionUID=1L;
                /**
 * 
 */
private String workExperienceId;
                        /**
 * ID
 */
private String customerId;
                        /**
 * 公司名称
 */
private String companyName;
                        /**
 * 公司性质
 */
private String companyType;
                        /**
 * 职务（字典）
 */
private String duty;

/**
 * 职务（字典）(文本)
 */
private String duty_text;
                        /**
 * 开始时间
 */
private Date beginDate;
                        /**
 * 结束时间
 */
private Date endDate;
                /**
 * orderBy
 */
private String orderByStr;

private String queryParam;
        }